﻿namespace RecipePlanner.Domain {
    public enum PrepTime {
        S,
        M,
        L
    }
}
