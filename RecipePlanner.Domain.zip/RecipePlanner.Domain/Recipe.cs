﻿namespace RecipePlanner.Domain {
    public class Recipe {
        public required int Id { get; set; }
        public required string Name { get; set; }
        public PrepTime PrepTime { get; set; }

        public List<RecipeIngredient> Ingredients { get; set; } = [];

    }
}
