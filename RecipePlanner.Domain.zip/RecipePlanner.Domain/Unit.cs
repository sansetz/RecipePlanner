﻿namespace RecipePlanner.Domain {
    public class Unit {

        public int Id { get; set; }
        public required string Name { get; set; }
    }
}
