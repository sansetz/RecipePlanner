﻿namespace RecipePlanner.Domain {
    public class Weekplan {
        public int Id { get; set; }
        public required DateTime StartDate { get; set; }
    }
}
